//
//  Xcode13ClockHandRotationEffect.h
//  Xcode13ClockHandRotationEffect
//
//  Created by 王小劣 on 2023/1/5.
//

#import <Foundation/Foundation.h>

//! Project version number for Xcode13ClockHandRotationEffect.
FOUNDATION_EXPORT double Xcode13ClockHandRotationEffectVersionNumber;

//! Project version string for Xcode13ClockHandRotationEffect.
FOUNDATION_EXPORT const unsigned char Xcode13ClockHandRotationEffectVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Xcode13ClockHandRotationEffect/PublicHeader.h>


