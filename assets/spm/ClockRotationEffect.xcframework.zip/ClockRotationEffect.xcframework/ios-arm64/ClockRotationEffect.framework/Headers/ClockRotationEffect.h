//
//  ClockRotationEffect.h
//  ClockRotationEffect
//
//  Created by 王小劣 on 2023/1/5.
//

#import <Foundation/Foundation.h>

//! Project version number for ClockRotationEffect.
FOUNDATION_EXPORT double ClockRotationEffectVersionNumber;

//! Project version string for ClockRotationEffect.
FOUNDATION_EXPORT const unsigned char ClockRotationEffectVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ClockRotationEffect/PublicHeader.h>


